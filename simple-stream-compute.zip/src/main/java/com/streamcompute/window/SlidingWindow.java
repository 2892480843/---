package com.streamcompute.window;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 滑动窗口实现
 * 基于事件时间的滑动窗口，支持窗口大小和滑动间隔的配置
 */
public class SlidingWindow<T> extends Window<T> {
    private static final Logger logger = LoggerFactory.getLogger(SlidingWindow.class);
    
    private Instant lastTriggerTime;
    
    /**
     * 创建一个新的滑动窗口
     * 
     * @param windowSize 窗口大小
     * @param slideInterval 滑动间隔
     */
    public SlidingWindow(Duration windowSize, Duration slideInterval) {
        super(windowSize, slideInterval);
        this.lastTriggerTime = Instant.now();
    }
    
    /**
     * 触发窗口计算
     * 当水位线超过 (上次触发时间 + 滑动间隔) 时，触发窗口计算
     * 
     * @return 窗口计算结果
     */
    @Override
    public List<T> trigger() {
        Instant nextTriggerTime = lastTriggerTime.plus(slideInterval);
        
        if (currentWatermark.isBefore(nextTriggerTime)) {
            // 水位线尚未达到下一个触发时间
            return new ArrayList<>();
        }
        
        // 计算窗口的开始和结束时间
        Instant windowEnd = currentWatermark;
        Instant windowStart = windowEnd.minus(windowSize);
        
        logger.debug("Triggering window computation for window [{} - {}]", windowStart, windowEnd);
        
        // 筛选出在当前窗口范围内的事件
        List<T> windowResults = events.stream()
                .filter(event -> !event.getEventTime().isBefore(windowStart) && 
                                 !event.getEventTime().isAfter(windowEnd))
                .sorted(Comparator.comparing(WindowEvent::getEventTime))
                .map(WindowEvent::getEvent)
                .collect(Collectors.toList());
        
        // 更新上次触发时间
        lastTriggerTime = nextTriggerTime;
        
        logger.info("Window triggered with {} events", windowResults.size());
        return windowResults;
    }
    
    /**
     * 获取上次触发时间
     * 
     * @return 上次触发时间
     */
    public Instant getLastTriggerTime() {
        return lastTriggerTime;
    }
}