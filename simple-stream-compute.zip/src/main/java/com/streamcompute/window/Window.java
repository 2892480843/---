package com.streamcompute.window;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 窗口抽象类，用于在事件时间语义下处理数据
 * 支持有限序数据的处理
 */
public abstract class Window<T> {
    private static final Logger logger = LoggerFactory.getLogger(Window.class);
    
    protected final Duration windowSize;
    protected final Duration slideInterval;
    protected final List<WindowEvent<T>> events;
    protected Instant currentWatermark;
    
    /**
     * 创建一个新的窗口
     * 
     * @param windowSize 窗口大小
     * @param slideInterval 滑动间隔
     */
    public Window(Duration windowSize, Duration slideInterval) {
        this.windowSize = windowSize;
        this.slideInterval = slideInterval;
        this.events = new ArrayList<>();
        this.currentWatermark = Instant.now();
    }
    
    /**
     * 添加事件到窗口
     * 
     * @param event 事件数据
     * @param eventTime 事件时间
     */
    public void addEvent(T event, Instant eventTime) {
        events.add(new WindowEvent<>(event, eventTime));
        logger.debug("Added event to window at time: {}", eventTime);
    }
    
    /**
     * 更新水位线
     * 水位线是一个时间戳，表示所有早于该时间戳的事件都已到达
     * 
     * @param newWatermark 新的水位线时间
     * @return 如果水位线前进则返回true，否则返回false
     */
    public boolean advanceWatermark(Instant newWatermark) {
        if (newWatermark.isAfter(currentWatermark)) {
            logger.debug("Advancing watermark from {} to {}", currentWatermark, newWatermark);
            currentWatermark = newWatermark;
            return true;
        }
        return false;
    }
    
    /**
     * 触发窗口计算
     * 当水位线超过窗口结束时间时，应该触发窗口计算
     * 
     * @return 窗口计算结果
     */
    public abstract List<T> trigger();
    
    /**
     * 清理过期的事件数据
     * 当事件时间早于 (当前水位线 - 允许的最大延迟) 时，可以安全地删除这些事件
     * 
     * @param maxLatenessDuration 允许的最大延迟
     */
    public void purgeExpiredEvents(Duration maxLatenessDuration) {
        Instant expiredThreshold = currentWatermark.minus(maxLatenessDuration);
        int initialSize = events.size();
        
        events.removeIf(event -> event.getEventTime().isBefore(expiredThreshold));
        
        int removedCount = initialSize - events.size();
        if (removedCount > 0) {
            logger.debug("Purged {} expired events before {}", removedCount, expiredThreshold);
        }
    }
    
    /**
     * 获取当前水位线
     * 
     * @return 当前水位线时间
     */
    public Instant getCurrentWatermark() {
        return currentWatermark;
    }
    
    /**
     * 获取窗口中的事件数量
     * 
     * @return 事件数量
     */
    public int getEventCount() {
        return events.size();
    }
    
    /**
     * 窗口事件内部类，存储事件数据及其时间戳
     */
    protected static class WindowEvent<T> {
        private final T event;
        private final Instant eventTime;
        
        public WindowEvent(T event, Instant eventTime) {
            this.event = event;
            this.eventTime = eventTime;
        }
        
        public T getEvent() {
            return event;
        }
        
        public Instant getEventTime() {
            return eventTime;
        }
    }
}