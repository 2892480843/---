package com.streamcompute.nodes;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.streamcompute.core.Node;

/**
 * 源节点，作为数据流的起点
 * 可以从外部数据源获取数据并发送到下游节点
 */
public class SourceNode<T> extends Node<Void, T> {
    private static final Logger logger = LoggerFactory.getLogger(SourceNode.class);
    
    private final Supplier<T> dataSupplier;
    
    /**
     * 创建一个新的源节点
     * 
     * @param name 节点名称
     * @param dataSupplier 数据提供者，用于生成数据
     */
    public SourceNode(String name, Supplier<T> dataSupplier) {
        super(name);
        this.dataSupplier = dataSupplier;
    }
    
    /**
     * 源节点不处理输入数据，此方法不应被直接调用
     */
    @Override
    public void process(Void input) {
        // 源节点不处理输入数据
        logger.warn("SourceNode should not receive input data");
    }
    
    /**
     * 生成一个数据项并发送到下游节点
     */
    public void generate() {
        T data = dataSupplier.get();
        logger.debug("SourceNode {} generated data: {}", getName(), data);
        emit(data);
    }
    
    /**
     * 生成指定数量的数据项并发送到下游节点
     * 
     * @param count 要生成的数据项数量
     */
    public void generateBatch(int count) {
        logger.info("SourceNode {} generating {} data items", getName(), count);
        for (int i = 0; i < count; i++) {
            generate();
        }
    }
}