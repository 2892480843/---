package com.streamcompute.nodes;

import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.streamcompute.core.Node;

/**
 * 处理节点，用于处理输入数据并产生输出结果
 * 是流计算系统中最常用的节点类型
 */
public class ProcessNode<IN, OUT> extends Node<IN, OUT> {
    private static final Logger logger = LoggerFactory.getLogger(ProcessNode.class);
    
    private final Function<IN, OUT> processor;
    
    /**
     * 创建一个新的处理节点
     * 
     * @param name 节点名称
     * @param processor 数据处理函数，将输入数据转换为输出数据
     */
    public ProcessNode(String name, Function<IN, OUT> processor) {
        super(name);
        this.processor = processor;
    }
    
    /**
     * 处理输入数据并产生输出
     * 
     * @param input 输入数据
     */
    @Override
    public void process(IN input) {
        logger.debug("ProcessNode {} processing data: {}", getName(), input);
        OUT output = processor.apply(input);
        logger.debug("ProcessNode {} produced result: {}", getName(), output);
        emit(output);
    }
}