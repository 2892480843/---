package com.streamcompute.nodes;

import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.streamcompute.core.Node;

/**
 * 接收节点，作为数据流的终点
 * 用于接收和处理最终的数据结果
 */
public class SinkNode<T> extends Node<T, Void> {
    private static final Logger logger = LoggerFactory.getLogger(SinkNode.class);
    
    private final Consumer<T> dataConsumer;
    
    /**
     * 创建一个新的接收节点
     * 
     * @param name 节点名称
     * @param dataConsumer 数据消费者，用于处理接收到的数据
     */
    public SinkNode(String name, Consumer<T> dataConsumer) {
        super(name);
        this.dataConsumer = dataConsumer;
    }
    
    /**
     * 处理输入数据
     * 
     * @param input 输入数据
     */
    @Override
    public void process(T input) {
        logger.debug("SinkNode {} received data: {}", getName(), input);
        dataConsumer.accept(input);
    }
    
    /**
     * 接收节点不发送数据到下游
     */
    @Override
    protected void emit(Void output) {
        // 接收节点不发送数据到下游
        logger.warn("SinkNode should not emit data");
    }
}