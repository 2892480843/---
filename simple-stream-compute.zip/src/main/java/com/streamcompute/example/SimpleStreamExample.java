package com.streamcompute.example;

import com.streamcompute.core.Edge;
import com.streamcompute.core.Graph;
import com.streamcompute.nodes.ProcessNode;
import com.streamcompute.nodes.SinkNode;
import com.streamcompute.nodes.SourceNode;
import com.streamcompute.retract.RetractableData;
import com.streamcompute.window.SlidingWindow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 简易流式计算系统示例
 * 展示系统的基本功能和中级特性
 */
public class SimpleStreamExample {
    private static final Logger logger = LoggerFactory.getLogger(SimpleStreamExample.class);
    private static final Random random = new Random();

    // 存储聚合结果的Map，用于演示retract处理
    private static final Map<String, Integer> aggregateResults = new HashMap<>();

    public static void main(String[] args) {
        logger.info("启动简易流式计算系统示例");

        // 创建流计算图
        Graph graph = new Graph("SimpleStreamGraph");

        // 创建源节点，生成随机传感器数据
        SourceNode<SensorData> sourceNode = new SourceNode<>("SensorSource", () -> {
            String sensorId = "sensor-" + (random.nextInt(3) + 1); // 随机生成3个传感器的数据
            int value = random.nextInt(100);
            return new SensorData(sensorId, value, Instant.now());
        });

        // 创建处理节点，将传感器数据转换为可撤回数据
        ProcessNode<SensorData, RetractableData<SensorData>> retractNode =
                new ProcessNode<>("RetractProcessor", data -> {
                    // 随机决定是否需要撤回之前的数据（模拟数据更新或错误修正）
                    if (random.nextInt(10) == 0) { // 10%的概率生成撤回操作
                        logger.info("生成撤回操作: {}", data.getSensorId());
                        return RetractableData.retract(data, data.getSensorId());
                    } else {
                        return RetractableData.insert(data, data.getSensorId());
                    }
                });

        // 创建窗口处理节点，使用滑动窗口聚合数据
        ProcessNode<RetractableData<SensorData>, WindowResult> windowNode =
                new ProcessNode<>("WindowProcessor", data -> {
                    // 处理retract操作
                    if (data.isRetract()) {
                        String key = data.getDataKey();
                        if (aggregateResults.containsKey(key)) {
                            logger.info("撤回数据: {}", key);
                            aggregateResults.remove(key);
                        }
                        return new WindowResult(key, 0, true);
                    }

                    // 正常数据处理
                    SensorData sensorData = data.getData();
                    String key = sensorData.getSensorId();
                    int currentValue = sensorData.getValue();

                    // 更新聚合结果
                    int newValue = aggregateResults.getOrDefault(key, 0) + currentValue;
                    aggregateResults.put(key, newValue);

                    return new WindowResult(key, newValue, false);
                });

        // 创建接收节点，输出最终结果
        SinkNode<WindowResult> sinkNode = new SinkNode<>("ResultSink", result -> {
            if (result.isRetracted()) {
                logger.info("结果已撤回: {}", result.getKey());
            } else {
                logger.info("聚合结果: {} = {}", result.getKey(), result.getValue());
            }
        });

        // 连接节点
        Edge<SensorData> sourceToRetract = new Edge<>("SourceToRetract", retractNode);
        sourceNode.addOutputEdge(sourceToRetract);

        Edge<RetractableData<SensorData>> retractToWindow = new Edge<>("RetractToWindow", windowNode);
        retractNode.addOutputEdge(retractToWindow);

        Edge<WindowResult> windowToSink = new Edge<>("WindowToSink", sinkNode);
        windowNode.addOutputEdge(windowToSink);

        // 添加节点和边到图中
        graph.addNode(sourceNode)
                .addNode(retractNode)
                .addNode(windowNode)
                .addNode(sinkNode)
                .addEdge(sourceToRetract)
                .addEdge(retractToWindow)
                .addEdge(windowToSink);

        // 启动图
        graph.start();

        // 创建滑动窗口，用于演示窗口处理
        SlidingWindow<SensorData> slidingWindow = new SlidingWindow<>(Duration.ofSeconds(5), Duration.ofSeconds(1));

        // 创建定时任务，定期生成数据和触发窗口计算
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);

        // 定期生成数据
        executor.scheduleAtFixedRate(() -> {
            sourceNode.generate();

            // 添加数据到窗口并更新水位线
            SensorData data = new SensorData("window-sensor", random.nextInt(100), Instant.now());
            slidingWindow.addEvent(data, data.getTimestamp());
            slidingWindow.advanceWatermark(Instant.now());
        }, 0, 500, TimeUnit.MILLISECONDS);

        // 定期触发窗口计算
        executor.scheduleAtFixedRate(() -> {
            List<SensorData> windowResults = slidingWindow.trigger();
            if (!windowResults.isEmpty()) {
                logger.info("窗口触发，包含 {} 个事件", windowResults.size());
                double average = windowResults.stream()
                        .mapToInt(SensorData::getValue)
                        .average()
                        .orElse(0);
                logger.info("窗口内数据平均值: {}", average);
            }

            // 清理过期事件
            slidingWindow.purgeExpiredEvents(Duration.ofSeconds(10));
        }, 1, 1, TimeUnit.SECONDS);

        // 运行一段时间后停止
        try {
            Thread.sleep(30000); // 运行30秒
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // 停止执行器和图
        executor.shutdown();
        graph.stop();

        logger.info("简易流式计算系统示例结束");
    }

    /**
     * 传感器数据类
     */
    public static class SensorData {
        private final String sensorId;
        private final int value;
        private final Instant timestamp;

        public SensorData(String sensorId, int value, Instant timestamp) {
            this.sensorId = sensorId;
            this.value = value;
            this.timestamp = timestamp;
        }

        public String getSensorId() {
            return sensorId;
        }

        public int getValue() {
            return value;
        }

        public Instant getTimestamp() {
            return timestamp;
        }

        @Override
        public String toString() {
            return "SensorData{" +
                    "sensorId='" + sensorId + '\'' +
                    ", value=" + value +
                    ", timestamp=" + timestamp +
                    '}';
        }
    }

    /**
     * 窗口计算结果类
     */
    public static class WindowResult {
        private final String key;
        private final int value;
        private final boolean retracted;

        public WindowResult(String key, int value, boolean retracted) {
            this.key = key;
            this.value = value;
            this.retracted = retracted;
        }

        public String getKey() {
            return key;
        }

        public int getValue() {
            return value;
        }

        public boolean isRetracted() {
            return retracted;
        }

        @Override
        public String toString() {
            return "WindowResult{" +
                    "key='" + key + '\'' +
                    ", value=" + value +
                    ", retracted=" + retracted +
                    '}';
        }
    }
}