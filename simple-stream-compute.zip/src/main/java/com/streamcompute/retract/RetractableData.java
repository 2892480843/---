package com.streamcompute.retract;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 可撤回数据包装类
 * 用于支持retract处理，允许系统撤回之前发送的数据
 */
public class RetractableData<T> {
    private static final Logger logger = LoggerFactory.getLogger(RetractableData.class);
    
    /**
     * 数据操作类型
     */
    public enum OperationType {
        /**
         * 插入新数据
         */
        INSERT,
        
        /**
         * 更新现有数据
         */
        UPDATE,
        
        /**
         * 删除现有数据（撤回）
         */
        RETRACT
    }
    
    private final T data;
    private final OperationType operationType;
    private final String dataKey;
    
    /**
     * 创建一个新的可撤回数据
     * 
     * @param data 原始数据
     * @param operationType 操作类型
     * @param dataKey 数据键，用于标识数据
     */
    public RetractableData(T data, OperationType operationType, String dataKey) {
        this.data = data;
        this.operationType = operationType;
        this.dataKey = dataKey;
    }
    
    /**
     * 创建一个插入操作的可撤回数据
     * 
     * @param data 原始数据
     * @param dataKey 数据键
     * @return 可撤回数据
     */
    public static <T> RetractableData<T> insert(T data, String dataKey) {
        return new RetractableData<>(data, OperationType.INSERT, dataKey);
    }
    
    /**
     * 创建一个更新操作的可撤回数据
     * 
     * @param data 原始数据
     * @param dataKey 数据键
     * @return 可撤回数据
     */
    public static <T> RetractableData<T> update(T data, String dataKey) {
        return new RetractableData<>(data, OperationType.UPDATE, dataKey);
    }
    
    /**
     * 创建一个撤回操作的可撤回数据
     * 
     * @param data 原始数据
     * @param dataKey 数据键
     * @return 可撤回数据
     */
    public static <T> RetractableData<T> retract(T data, String dataKey) {
        return new RetractableData<>(data, OperationType.RETRACT, dataKey);
    }
    
    /**
     * 获取原始数据
     * 
     * @return 原始数据
     */
    public T getData() {
        return data;
    }
    
    /**
     * 获取操作类型
     * 
     * @return 操作类型
     */
    public OperationType getOperationType() {
        return operationType;
    }
    
    /**
     * 获取数据键
     * 
     * @return 数据键
     */
    public String getDataKey() {
        return dataKey;
    }
    
    /**
     * 检查是否为撤回操作
     * 
     * @return 如果是撤回操作则返回true，否则返回false
     */
    public boolean isRetract() {
        return operationType == OperationType.RETRACT;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RetractableData<?> that = (RetractableData<?>) o;
        return Objects.equals(dataKey, that.dataKey);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(dataKey);
    }
    
    @Override
    public String toString() {
        return "RetractableData{" +
                "data=" + data +
                ", operationType=" + operationType +
                ", dataKey='" + dataKey + '\'' +
                '}';
    }
}