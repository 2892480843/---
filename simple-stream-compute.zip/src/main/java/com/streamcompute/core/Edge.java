package com.streamcompute.core;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 流计算系统中的边
 * 边连接两个节点，负责数据的传输
 */
public class Edge<T> {
    private static final Logger logger = LoggerFactory.getLogger(Edge.class);
    
    private final String id;
    private final String name;
    private final Node<T, ?> targetNode;
    
    /**
     * 创建一个新的边
     * 
     * @param name 边的名称
     * @param targetNode 目标节点
     */
    public Edge(String name, Node<T, ?> targetNode) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.targetNode = targetNode;
    }
    
    /**
     * 传输数据到目标节点
     * 
     * @param data 要传输的数据
     */
    public void transmit(T data) {
        logger.debug("Edge {} transmitting data: {}", name, data);
        targetNode.process(data);
    }
    
    /**
     * 获取边的ID
     * 
     * @return 边的ID
     */
    public String getId() {
        return id;
    }
    
    /**
     * 获取边的名称
     * 
     * @return 边的名称
     */
    public String getName() {
        return name;
    }
    
    /**
     * 获取目标节点
     * 
     * @return 目标节点
     */
    public Node<T, ?> getTargetNode() {
        return targetNode;
    }
}