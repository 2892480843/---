package com.streamcompute.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 流计算图
 * 管理节点和边，控制数据流的执行
 */
public class Graph {
    private static final Logger logger = LoggerFactory.getLogger(Graph.class);
    
    private final String name;
    private final Map<String, Node<?, ?>> nodes;
    private final List<Edge<?>> edges;
    private boolean isRunning;
    
    /**
     * 创建一个新的流计算图
     * 
     * @param name 图的名称
     */
    public Graph(String name) {
        this.name = name;
        this.nodes = new HashMap<>();
        this.edges = new ArrayList<>();
        this.isRunning = false;
    }
    
    /**
     * 添加节点到图中
     * 
     * @param node 要添加的节点
     * @return 当前图实例，用于链式调用
     */
    public Graph addNode(Node<?, ?> node) {
        nodes.put(node.getId(), node);
        logger.info("Added node {} to graph {}", node.getName(), name);
        return this;
    }
    
    /**
     * 添加边到图中
     * 
     * @param edge 要添加的边
     * @return 当前图实例，用于链式调用
     */
    public Graph addEdge(Edge<?> edge) {
        edges.add(edge);
        logger.info("Added edge {} to graph {}", edge.getName(), name);
        return this;
    }
    
    /**
     * 启动流计算图
     */
    public void start() {
        if (isRunning) {
            logger.warn("Graph {} is already running", name);
            return;
        }
        
        logger.info("Starting graph {}", name);
        
        // 初始化所有节点
        for (Node<?, ?> node : nodes.values()) {
            node.initialize();
        }
        
        isRunning = true;
        logger.info("Graph {} started successfully", name);
    }
    
    /**
     * 停止流计算图
     */
    public void stop() {
        if (!isRunning) {
            logger.warn("Graph {} is not running", name);
            return;
        }
        
        logger.info("Stopping graph {}", name);
        
        // 关闭所有节点
        for (Node<?, ?> node : nodes.values()) {
            node.close();
        }
        
        isRunning = false;
        logger.info("Graph {} stopped successfully", name);
    }
    
    /**
     * 获取图的名称
     * 
     * @return 图的名称
     */
    public String getName() {
        return name;
    }
    
    /**
     * 检查图是否正在运行
     * 
     * @return 如果图正在运行则返回true，否则返回false
     */
    public boolean isRunning() {
        return isRunning;
    }
    
    /**
     * 获取节点数量
     * 
     * @return 节点数量
     */
    public int getNodeCount() {
        return nodes.size();
    }
    
    /**
     * 获取边数量
     * 
     * @return 边数量
     */
    public int getEdgeCount() {
        return edges.size();
    }
}