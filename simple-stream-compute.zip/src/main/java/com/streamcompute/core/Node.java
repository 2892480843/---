package com.streamcompute.core;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 流计算系统中的节点抽象类
 * 节点是流计算图中的基本处理单元
 */
public abstract class Node<IN, OUT> {
    private static final Logger logger = LoggerFactory.getLogger(Node.class);
    
    private final String id;
    private final String name;
    private final List<Edge<OUT>> outputEdges;
    
    /**
     * 构造一个新的节点
     * 
     * @param name 节点名称
     */
    public Node(String name) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.outputEdges = new ArrayList<>();
    }
    
    /**
     * 处理输入数据并产生输出
     * 
     * @param input 输入数据
     */
    public abstract void process(IN input);
    
    /**
     * 向下游节点发送数据
     * 
     * @param output 输出数据
     */
    protected void emit(OUT output) {
        logger.debug("Node {} emitting data: {}", name, output);
        for (Edge<OUT> edge : outputEdges) {
            edge.transmit(output);
        }
    }
    
    /**
     * 添加一个输出边到当前节点
     * 
     * @param edge 输出边
     */
    public void addOutputEdge(Edge<OUT> edge) {
        outputEdges.add(edge);
    }
    
    /**
     * 获取节点ID
     * 
     * @return 节点ID
     */
    public String getId() {
        return id;
    }
    
    /**
     * 获取节点名称
     * 
     * @return 节点名称
     */
    public String getName() {
        return name;
    }
    
    /**
     * 初始化节点
     */
    public void initialize() {
        logger.info("Initializing node: {}", name);
    }
    
    /**
     * 关闭节点
     */
    public void close() {
        logger.info("Closing node: {}", name);
    }
}